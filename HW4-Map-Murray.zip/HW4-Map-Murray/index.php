<!DOCTYPE html>
<meta charset="utf-8">

<head>

<link rel="stylesheet" href="map.css">
<title>FE550 Map Visualization</title>

</head>
<body>

<div class="container">
  	<div class="header">
		<center>Shawn Murray - FE-550 Map Visualization - Sea Surface Temperature Time Lapse</center>      
	</div> <!-- end of header -->
    
    <div class="iceMap">
    <center><img id="img" src="data/1990-01-ice.png" width=800 height=600 /></center></div>
	</div>
    
    
	<div class="top-container" id="top-cont">
    <hr>
    <h4>Description:</h4> 
	<blockquote>This page demonstrates a map visualization using an array of png image files. There are 300 images stored in a local directory created using a Python script.
    The images show the sea surface temperature (SST) and sea ice on the 1st day of each month from the start of 1990 through 2014. </blockquote>
    <h4>Data Source: </h4><blockquote>  The data is sourced from <a href="http://www.ncdc.noaa.gov/">The National Oceanic and Atmospheric Administration</a>
     </blockquote> 
	<h4>Code Description:</h4><blockquote>The Python code was sourced from <a href="http://matplotlib.org/basemap/users/index.html">http://matplotlib.org/basemap/users/index.html</a>. I made minor modifications to the code to adapt it the project.  A copy of the code can be found locally here - <a href="python-map-ice.txt">python-map-ice.txt file</a>.  
    The code was run on my local machine to create the images.  The code requires several libraries to be present including numpy and matplotlib. PHP code is used on the page to discover the images in the data directory and to pass an array of image names to the page script.  The script then runs a continous loop, accessing the DOM ID of the current image and updating it to the next image in the array with a 500 ms delay.  

 <br>
 </blockquote>   



<?PHP
	// use PHP to index the local data directory with the images
    //The directory 
    $data_dir = 'data/';
	//test if it is a directory
	if (is_dir($data_dir)) {
    	$filenames = scandir($data_dir, 0);

	} else {
    	echo "No such directory";
		echo $data_dir;
	}
    
    //This array will hold all the image addresses
    $result = array();

    //Get all the files in the specified directory
    $files = scandir($data_dir);
	
    foreach($files as $file) {
        switch(ltrim(strstr($file, '.'), '.')) {

            //If the file is an image, add it to the array
            case "jpg": case "jpeg":case "png":case "gif":

                $result[] = $file;
 		  }
    }
	//just in case it needs sorting
	sort($result);	
	//start script and pass the array to the client script as json 
?>
<script language="JavaScript">
var image_list = <?php echo json_encode($result) ; ?>; 
var interval = 1500;
var random_dsiplay = 0;
var imageDir = "data/";
var i = 0;
var nextImage = imageDir.concat(image_list[i]);
var totalImages = image_list.length;

function slideshow() {
		nextImage = imageDir.concat(image_list[i]);
		document.getElementById("img").src = nextImage;
   		if(i < totalImages - 1) i++; else i = 0;
   		setTimeout("slideshow()",500);
		//document.write(nextImage);
}		
window.onload=slideshow;
</script>


<!-- end containers --></div></div>
</body>